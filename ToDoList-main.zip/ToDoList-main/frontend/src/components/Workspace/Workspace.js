import styles from './Workspace.css'
import Group from '../Group/Group'


export default function Workspace() {
    return (
        <main style={styles}>
            <p>workspace</p>
            
        </main>
    );
}