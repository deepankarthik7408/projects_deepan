import styles from './Task.css'


export default function Task() {
    return (
        <div className="task" style={styles}>
            task
        </div>
    )
}