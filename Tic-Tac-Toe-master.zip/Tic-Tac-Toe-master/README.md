# Tic-Tac-Toe

A simple Tic Tac Tao game written in Python with AI (min-max algorithm)
